@extends('layouts.default')


@section('title','Sis.RH')
@section('conteudo')
    <h1>Dashboards</h1>
    <p>Aqui é a view principal do sistema</p>
@endsection