

<?php $__env->startSection('title','Funcionários'); ?>


<?php $__env->startSection('conteudo'); ?>
    <h1>Funcionários</h1>
        <a href="<?php echo e(route('funcionarios.create')); ?>" class="btn btn-primary float-end mb-2 rounded-circle fs-4"><i class="bi bi-person-plus-fill"></i></a>
    <table class="table table-striped">
        <thead class="table-dark">
            <tr>
                <th>ID</th>
                <th>Foto</th>
                <th>Nome</th>
                <th>Cargos</th>
                <th>Departamento</th>
                <th>Ação</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $funcionarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $funcionario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($funcionario->id); ?></td>
                <td><img src="/images/funcionarios/<?php echo e($funcionario->foto); ?>" alt="<?php echo e($funcionario->nome); ?>" width="100"></td>
                <td><?php echo e($funcionario->nome); ?></td>
                <td><?php echo e($funcionario->cargo->descricao); ?></td>
                <td><?php echo e($funcionario->departamento->nome); ?></td>
                <td>
                    <a href="#" class="btn btn-primary mb-2 fs-8"><i class="bi bi-pen"></i></a>
                    <a href="#" class="btn btn-danger mb-2 fs-8"><i class="bi bi-trash3"></i></a>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>

    </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\gabri\sisrh\resources\views/funcionarios/index.blade.php ENDPATH**/ ?>