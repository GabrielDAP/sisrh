


<?php $__env->startSection('title','Sis.RH'); ?>
<?php $__env->startSection('conteudo'); ?>
    <h1>Dashboards</h1>
    <p>Aqui é a view principal do sistema</p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\gabri\sisrh\resources\views/index.blade.php ENDPATH**/ ?>