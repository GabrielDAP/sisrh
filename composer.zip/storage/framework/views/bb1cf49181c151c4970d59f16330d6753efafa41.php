

<?php $__env->startSection('title','Cadastrar Departamentos'); ?>


<?php $__env->startSection('conteudo'); ?>
    <body class="bg-light">
        <div class="container border border-2 rounded-4 p-4 bg-white mb-5" style="max-width: 1200px;">
            <form method="POST">
                <h1 class="mb-4">Cadastrar Departamentos</h1>
                <div class="row">
                    <div class="mb-3">
                        <label for="descricao" class="form-label fw-bold">Descrição:</label>
                        <input type="text" name="nome" class="form-control form-control-lg bg-light" value="" required>
                    </div>

                    <div class="d-grid mb-4 col-sm-2">
                        <input type="button" value="Cadastrar" class="btn btn-outline-primary btn-lg">
                    </div>
    
                    <div class="d-grid mb-4 col-sm-2">
                        <input type="button" value="Cancelar" class="btn btn-outline-danger btn-lg">
                    </div>
                </div>
                
            </form>
        </div>

        <script src="js/bootstrap.bundle.min.js"></script>
    </body>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\gabri\sisrh\resources\views/departamentos/create.blade.php ENDPATH**/ ?>